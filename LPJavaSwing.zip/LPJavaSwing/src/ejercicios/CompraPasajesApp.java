package ejercicios;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CompraPasajesApp extends JFrame {
    private final JFrame ventana1; 
    private JFrame ventana2; 
    private JFrame ventana3;
    private JFrame ventana4;
    
    private final JButton boton1, boton2, boton3, boton4, boton5;
    
    private String nombre, apellido, dni, telefono;
    private String tipoViaje, origen, destino, calidad;
    private String audifonos, frasada, revistas, bebidas, aperitivos, piso;

    public CompraPasajesApp() {
        ventana1 = new JFrame("Bienvenidos a la Empresa Transportes VIA");
        ventana1.setLayout(new BorderLayout());

        ImageIcon imagen = new ImageIcon("C:\\imagen\\empresa.png");
        JLabel labelImagen = new JLabel(imagen);
        ventana1.add(labelImagen, BorderLayout.NORTH);

        JPanel panelBotones = new JPanel();
		this.ventana2 = new JFrame();
		this.ventana3 = new JFrame();
		this.ventana4 = new JFrame();
		boton1 = new JButton("Ingreso para el registro");
		boton2 = new JButton("Compra del boleto");
		boton3 = new JButton("Servicios Opcionales");
		boton4 = new JButton("Información Total");
		boton5 = new JButton("Salir");

        panelBotones.add(boton1);
        panelBotones.add(boton2);
        panelBotones.add(boton3);
        panelBotones.add(boton4);
        panelBotones.add(boton5);
        ventana1.add(panelBotones, BorderLayout.CENTER);

        boton1.addActionListener(e -> abrirVentanaRegistro());
        boton2.addActionListener(e -> abrirVentanaCompra());
        boton3.addActionListener(e -> abrirVentanaServicios());
        boton4.addActionListener(e -> mostrarInformacion());
        boton5.addActionListener(e -> System.exit(0));

        ventana1.setSize(500, 350);
        ventana1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana1.setVisible(true);
    }

    private void abrirVentanaRegistro() {
    	ventana1.setVisible(false);
    	ventana2 = new JFrame("Datos Personales");
    	ventana2.setLayout(new GridLayout(5, 2));

        JTextField Nombre = new JTextField();
        JTextField Apellido = new JTextField();
        JTextField Dni = new JTextField();
        JTextField Telefono = new JTextField();

        ventana2.add(new JLabel("Nombre:"));
        ventana2.add(Nombre);
        ventana2.add(new JLabel("Apellido:"));
        ventana2.add(Apellido);
        ventana2.add(new JLabel("DNI:"));
        ventana2.add(Dni);
        ventana2.add(new JLabel("Teléfono:"));
        ventana2.add(Telefono);

        JButton Guardado = new JButton("Guardar");
        Guardado.addActionListener(e -> {
            nombre = Nombre.getText();
            apellido = Apellido.getText();
            dni = Dni.getText();
            telefono = Telefono.getText();
            ventana2.dispose();
            ventana1.setVisible(true);
        });
        ventana2.add(Guardado);

        ventana2.setSize(300, 200);
        ventana2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ventana2.setVisible(true);
    }

    private void abrirVentanaCompra() {
    	ventana1.setVisible(false);
    	ventana3 = new JFrame("Datos de Compra");
    	ventana3.setLayout(new GridLayout(6, 2));

        JTextField DniCompra = new JTextField();
        JTextField Destino = new JTextField();
        JTextField Origen = new JTextField();
        JComboBox<String> cbCalidad = new JComboBox<>(new String[]{"Económico", "Estándar", "VIP"});
        JRadioButton Ida = new JRadioButton("Ida");
        JRadioButton IdaVuelta = new JRadioButton("Ida y vuelta");
        ButtonGroup grupoViaje = new ButtonGroup();
        grupoViaje.add(Ida);
        grupoViaje.add(IdaVuelta);

        ventana3.add(new JLabel("DNI:"));
        ventana3.add(DniCompra);
        ventana3.add(new JLabel("Lugar de Destino:"));
        ventana3.add(Destino);
        ventana3.add(new JLabel("Lugar de Origen:"));
        ventana3.add(Origen);
        ventana3.add(new JLabel("Calidad:"));
        ventana3.add(cbCalidad);
        ventana3.add(new JLabel("Tipo de Viaje:"));
        JPanel panelViaje = new JPanel();
        panelViaje.add(Ida);
        panelViaje.add(IdaVuelta);
        ventana3.add(panelViaje);

        JButton btnGuardarCompra = new JButton("Guardar");
        btnGuardarCompra.addActionListener(e -> {
            tipoViaje = Ida.isSelected() ? "Ida" : "Ida y vuelta";
            origen = Origen.getText();
            destino = Destino.getText();
            calidad = (String) cbCalidad.getSelectedItem();
            ventana3.dispose();
            ventana1.setVisible(true);
        });
        ventana3.add(btnGuardarCompra);

        ventana3.setSize(300, 250);
        ventana3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ventana3.setVisible(true);
    }

    private void abrirVentanaServicios() {
    	ventana1.setVisible(false);
    	ventana4 = new JFrame("Servicios Opcionales");
    	ventana4.setLayout(new GridLayout(7, 2));

        JCheckBox Audifonos = new JCheckBox("Audífonos");
        JCheckBox Frasada = new JCheckBox("Frasada");
        JCheckBox Revistas = new JCheckBox("Revistas");
        JCheckBox Bebidas = new JCheckBox("Bebidas");
        JCheckBox Aperitivos = new JCheckBox("Aperitivos");
        JComboBox<String> cbPiso = new JComboBox<>(new String[]{"1ro", "2do"});

        ventana4.add(Audifonos);
        ventana4.add(Frasada);
        ventana4.add(Revistas);
        ventana4.add(Bebidas);
        ventana4.add(Aperitivos);
        ventana4.add(new JLabel("Piso del viaje:"));
        ventana4.add(cbPiso);

        JButton btnGuardarServicios = new JButton("Guardar");
        btnGuardarServicios.addActionListener(e -> {
            audifonos = Audifonos.isSelected() ? "Sí" : "No";
            frasada = Frasada.isSelected() ? "Sí" : "No";
            revistas = Revistas.isSelected() ? "Sí" : "No";
            bebidas = Bebidas.isSelected() ? "Sí" : "No";
            aperitivos = Aperitivos.isSelected() ? "Sí" : "No";
            piso = (String) cbPiso.getSelectedItem();
            ventana4.dispose();
            ventana1.setVisible(true);
        });
        ventana4.add(btnGuardarServicios);

        ventana4.setSize(300, 300);
        ventana4.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ventana4.setVisible(true);
    }

    private void mostrarInformacion() {
        String informacion = "Información Total:\n";
        informacion += "Datos Personales:\nNombre: " + nombre + "\nApellido: " + apellido + "\nDNI: " + dni + "\nTeléfono: " + telefono;
        informacion += "\nDatos de Compra:\nTipo de Viaje: " + tipoViaje + "\nOrigen: " + origen + "\nDestino: " + destino + "\nCalidad: " + calidad;
        informacion += "\nServicios Opcionales:\nAudífonos: " + audifonos + "\nFrasada: " + frasada + "\nRevistas: " + revistas + "\nBebidas: " + bebidas;
        informacion += "\nAperitivos: " + aperitivos + "\nPiso: " + piso;
        JOptionPane.showMessageDialog(this, informacion, "Información Total", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        new CompraPasajesApp();
    }
}

