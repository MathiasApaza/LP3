package ejercicios;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VentanaBorderLayout extends JFrame {
    public VentanaBorderLayout() {
        setTitle("Calculadora Simple - BorderLayout");
        setLayout(new BorderLayout(10, 10));
        
        JTextField display = new JTextField();
        display.setHorizontalAlignment(JTextField.RIGHT);
        add(display, BorderLayout.NORTH);
        
        JPanel boton1 = new JPanel(new GridLayout(4, 4, 5, 5));
        String[] botones = {"7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "C", "0", "=", "+"};
        
        for (String texto : botones) {
            JButton button = new JButton(texto);
            boton1.add(button);
        }
        add(boton1, BorderLayout.CENTER);
        
        JButton borrado = new JButton("Limpiar");
        borrado.addActionListener(e -> display.setText(""));
        add(borrado, BorderLayout.SOUTH);
        
        setSize(300, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new VentanaBorderLayout();
    }
}

