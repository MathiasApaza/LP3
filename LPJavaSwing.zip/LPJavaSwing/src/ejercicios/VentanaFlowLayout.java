package ejercicios;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VentanaFlowLayout extends JFrame {
    public VentanaFlowLayout() {
        setTitle("Registro de Usuario");
        setLayout(new FlowLayout(FlowLayout.CENTER, 15, 10));
        
        JLabel nombre = new JLabel("Nombre:");
        JTextField nombreField = new JTextField(15);
        JLabel email = new JLabel("Email:");
        JTextField emailField = new JTextField(15);
        JButton registro = new JButton("Registrar");
        
        registro.addActionListener(e -> 
            JOptionPane.showMessageDialog(this, "Usuario registrado con éxito")
        );

        add(nombre);
        add(nombreField);
        add(email);
        add(emailField);
        add(registro);
        
        setSize(300, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new VentanaFlowLayout();
    }
}
