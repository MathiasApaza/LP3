package ejercicios;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VentanaGridLayout extends JFrame {
    public VentanaGridLayout() {
        setTitle("Selección de Materias - GridLayout");
        setLayout(new GridLayout(4, 2, 10, 10));
        
        JLabel subjectLabel = new JLabel("Materia:");
        JComboBox<String> subjectBox = new JComboBox<>(new String[] {
            "Matemáticas", "Historia", "Biología", "Física"
        });
        
        JLabel dayLabel = new JLabel("Día:");
        JComboBox<String> dayBox = new JComboBox<>(new String[] {
            "Lunes", "Miércoles", "Viernes"
        });
        
        JLabel timeLabel = new JLabel("Hora:");
        JComboBox<String> timeBox = new JComboBox<>(new String[] {
            "8:00 AM", "10:00 AM", "2:00 PM"
        });
        
        JButton registerButton = new JButton("Registrar");
        registerButton.addActionListener(e -> 
            JOptionPane.showMessageDialog(this, "Materia registrada con éxito.")
        );

        add(subjectLabel);
        add(subjectBox);
        add(dayLabel);
        add(dayBox);
        add(timeLabel);
        add(timeBox);
        add(new JLabel());
        add(registerButton);
        
        setSize(350, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new VentanaGridLayout();
    }
}
