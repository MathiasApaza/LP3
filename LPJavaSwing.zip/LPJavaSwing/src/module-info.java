/**
 * 
 */
/**
 * 
 */
module LPJavaSwing {
	requires java.desktop;
}