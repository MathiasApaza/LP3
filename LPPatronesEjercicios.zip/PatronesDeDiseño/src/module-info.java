/**
 * 
 */
/**
 * 
 */
module PatronesDeDiseño {
}