package patrones;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Producto {
    private String nombre;
    private double precio;

    public Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }
}

class SinDescuento {
    public double calcular(List<Producto> productos) {
        return productos.stream().mapToDouble(Producto::getPrecio).sum();
    }
}

class DescuentoFijo {
    public double calcular(List<Producto> productos) {
        double total = productos.stream().mapToDouble(Producto::getPrecio).sum();
        return total * 0.9; 
    }
}

class DescuentoPorcentual {
    public double calcular(List<Producto> productos) {
        double total = 0;
        List<Producto> procesados = new ArrayList<>();
        for (Producto p : productos) {
            long count = productos.stream().filter(x -> x.getNombre().equals(p.getNombre())).count();
            if (count >= 2 && !procesados.contains(p)) {
                total += p.getPrecio() * 0.7 * count; 
                procesados.add(p);
            } else if (!procesados.contains(p)) {
                total += p.getPrecio() * count;
            }
        }
        return total;
    }
}

public class SistemaDescuentos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Producto> productos = new ArrayList<>();
        productos.add(new Producto("ProductoA", 100));
        productos.add(new Producto("ProductoA", 100));
        productos.add(new Producto("ProductoB", 50));
        productos.add(new Producto("ProductoC", 200));

        while (true) {
            System.out.println("---------Menu de Descuento--------");
            System.out.println("1. Sin Descuento");
            System.out.println("2. Descuento Fijo");
            System.out.println("3. Descuento Porcentual");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();

            double precioFinal = 0;
            switch (opcion) {
                case 1:
                    precioFinal = new SinDescuento().calcular(productos);
                    break;
                case 2:
                    precioFinal = new DescuentoFijo().calcular(productos);
                    break;
                case 3:
                    precioFinal = new DescuentoPorcentual().calcular(productos);
                    break;
                case 4:
                    System.out.println("Saliendo del sistema");
                    return;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
                    continue;
            }

            System.out.printf("El precio final es: %.2f%n", precioFinal);
        }
    }
}