package patrones;

import java.util.ArrayList;
import java.util.List;

interface Observer {
    void recibirNotificacion(String mensaje);
}

class Usuario implements Observer {
    private String nombre;

    public Usuario(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void recibirNotificacion(String mensaje) {
        System.out.println(nombre + " recibió: " + mensaje);
    }

    public String getNombre() {
        return nombre;
    }
}

interface Subject {
    void suscribir(Observer observer);
    void desuscribir(Observer observer);
    void notificar(String mensaje);
}

class Notificacion implements Subject {
    private List<Observer> observadores = new ArrayList<>();

    @Override
    public void suscribir(Observer observer) {
        observadores.add(observer);
        System.out.println(((Usuario) observer).getNombre() + " se registro en el sistema");
    }

    @Override
    public void desuscribir(Observer observer) {
        observadores.remove(observer);
        System.out.println(((Usuario) observer).getNombre() + " se ha retirado completamente del sistema");
    }

    @Override
    public void notificar(String mensaje) {
        for (Observer observer : observadores) {
            observer.recibirNotificacion(mensaje);
        }
    }
}

public class SistemaNotificaciones {
    public static void main(String[] args) {
        Notificacion notificacion = new Notificacion();

        Usuario usuario1 = new Usuario("Jesus");
        Usuario usuario2 = new Usuario("Pedro");

        notificacion.suscribir(usuario1);
        notificacion.suscribir(usuario2);

        notificacion.notificar("Se le comunica que hay mas de 1 producto con el 50% de descuento");
        notificacion.notificar("Ya se acerca la navidad que esperas para los descuentos mas increibles por las fechas navideñas");
        
        notificacion.desuscribir(usuario2);
        notificacion.notificar("Se abrio una nueva sucursal por tu ciudad, que esperas para ir");

        
    }
}
