package patrones;

interface Comando {
	void ejecutar();
}

class Luz {
	public void encender() {
		System.out.println("La luz está encendida.");
	}

	public void apagar() {
		System.out.println("La luz está apagada.");
	}
}

class ComandoEncenderLuz implements Comando {
	private Luz luz;

	public ComandoEncenderLuz(Luz luz) {
		this.luz = luz;
	}

	 @Override
	 public void ejecutar() {
	     luz.encender();
	 }
}

class ComandoApagarLuz implements Comando {
	 private Luz luz;
	
	 public ComandoApagarLuz(Luz luz) {
	     this.luz = luz;
	 }
	
	 @Override
	 public void ejecutar() {
	     luz.apagar();
	 }
}

class ControlRemoto {
	 private Comando comando;
	
	 public void setComando(Comando comando) {
	     this.comando = comando;
	 }
	
	 public void presionarBoton() {
	     comando.ejecutar();
	 }
}

public class SistemadeControl {
	 public static void main(String[] args) {
	     Luz luz = new Luz();
	
	     Comando encenderLuz = new ComandoEncenderLuz(luz);
	     Comando apagarLuz = new ComandoApagarLuz(luz);
	
	     ControlRemoto controlRemoto = new ControlRemoto();
	
	     controlRemoto.setComando(encenderLuz);
	     controlRemoto.presionarBoton();
	
	     controlRemoto.setComando(apagarLuz);
	     controlRemoto.presionarBoton();
	 }
}